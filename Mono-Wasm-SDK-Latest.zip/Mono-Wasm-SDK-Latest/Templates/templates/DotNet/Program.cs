﻿using System;

namespace WasmTemplate.1
{
    public class Program
    {
        public static void Main(string greeting) {
            Console.WriteLine($"Hello {greeting}");
        }
    }
}
