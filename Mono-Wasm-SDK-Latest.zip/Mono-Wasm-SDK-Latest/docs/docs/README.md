# Document Guide

| Folder | Description |
| --- | --- |
| [getting-started](./getting-started) | Contains a list of documents on Getting Started with the Mono WebAssembly SDK |
| [packager](./packager.md) | Using the supplied packager utility.  |
